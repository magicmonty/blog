<?php
	$wgAccessControlDisableMessages = false;
	$wgAccessControlGroupPrefix = "Benutzergruppe";
	$wgAccessControlNoAccessPage = "/wiki/index.php?title=Kein_Zugriff";
	$wgWikiVersion = 1.7;
?>
